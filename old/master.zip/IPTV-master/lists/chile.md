<h1>Chile</h1>

| #  | Channel        | Link  | Logo | EPG id |
|:--:|:--------------:|:-----:|:----:|:------:|
| 1  | UCV Televisión | [>](https://unlimited1-cl-isp.dps.live/ucvtv2/ucvtv2.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/2VL4Pts.png"/> | UCVTV.cl |
| 2  | TVN Ⓖ | [>](https://sktv-forwarders.7m.pl/get.php?x=TVN) | <img height="20" src="https://i.imgur.com/WoN1dai.png"/> | TVN.cl |
| 3  | 24 horas | [>](https://mdstrm.com/live-stream-playlist/57d1a22064f5d85712b20dab.m3u8) | <img height="20" src="https://i.imgur.com/0rF6Kub.png"/> | 24Horas.cl |
| 4  | NTV Ⓖ | [>](https://mdstrm.com/live-stream-playlist/5aaabe9e2c56420918184c6d.m3u8) | <img height="20" src="https://i.imgur.com/pt2Kj1A.png"/> | NTV.cl |
| 5  | TV Chile Ⓖ | [>](https://mdstrm.com/live-stream-playlist/533adcc949386ce765657d7c.m3u8) | <img height="20" src="https://i.imgur.com/yCL888l.png"/> | TVChile.cl |
| 6  | Canal 13 | [>](https://sktv-forwarders.7m.pl/get.php?x=Canal13) | <img height="20" src="https://i.imgur.com/JIo1HBs.png"/> | Canal13.cl |
| 7  | TV+ Ⓖ | [>](https://mdstrm.com/live-stream-playlist/5c0e8b19e4c87f3f2d3e6a59.m3u8) | <img height="20" src="https://i.imgur.com/NtuZIEJ.png"/> | TVPlus.cl |
| 8  | Chilevisión Ⓖ | [>](https://sktv-forwarders.7m.pl/get.php?x=Chilevision) | <img height="20" src="https://i.imgur.com/2Pu8yXf.png"/> | ChileVision.cl |
| 9  | UChile TV | [>](https://unlimited1-us.dps.live/uchiletv/uchiletv.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/mF2W8Uh.png"/> | UChileTV.cl |
| 10 | T13 en vivo | [>](https://redirector.rudo.video/hls-video/10b92cafdf3646cbc1e727f3dc76863621a327fd/t13/t13.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/3CEijac.png"/> | T13.cl |
| 11 | 13 Entretención | [>](https://origin.dpsgo.com/ssai/event/BBp0VeP6QtOOlH8nu3bWTg/master.m3u8) | <img height="20" src="https://i.imgur.com/1vTno0m.png"/> | 13E.cl |
| 12 | 13 Cultura | [>](https://origin.dpsgo.com/ssai/event/GI-9cp_bT8KcerLpZwkuhw/master.m3u8) | <img height="20" src="https://i.imgur.com/49QkKWv.png"/> | 13C.cl |
| 13 | 13 Prime | [>](https://origin.dpsgo.com/ssai/event/p4mmBxEzSmKAxY1GusOHrw/master.m3u8) | <img height="20" src="https://i.imgur.com/YwDFNxs.png"/> | 13P.cl |
| 14 | 13 Kids | [>](https://origin.dpsgo.com/ssai/event/LhHrVtyeQkKZ-Ye_xEU75g/master.m3u8) | <img height="20" src="https://i.imgur.com/m6y9AMe.png"/> | 13Kids.cl |
| 15 | 13 Realities | [>](https://origin.dpsgo.com/ssai/event/g7_JOM0ORki9SR5RKHe-Kw/master.m3u8) | <img height="20" src="https://i.imgur.com/p1Qpljw.png"/> | 13Realities.cl |
| 16 | 13 Teleseries | [>](https://origin.dpsgo.com/ssai/event/f4TrySe8SoiGF8Lu3EIq1g/master.m3u8) | <img height="20" src="https://i.imgur.com/aJMBnse.png"/> | 13T.cl |
| 17 | El Pingüino TV | [>](https://redirector.rudo.video/hls-video/339f69c6122f6d8f4574732c235f09b7683e31a5/pinguinotv/pinguinotv.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ohXs2NV.png"/> | ElPinguinoTV.cl |
| 18 | UCL | [>](https://redirector.rudo.video/hls-video/c54ac2799874375c81c1672abb700870537c5223/ucl/ucl.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/JxqVHPX.png"/> | UCL.uy |
| 19 | Deportes13 Ⓖ | [>](https://redirector.rudo.video/hls-video/ey6283je82983je9823je8jowowiekldk9838274/13d/13d.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/GRpxoPf.png"/> | D13.cl |
| 20 | TVN 3 | [>](https://mdstrm.com/live-stream-playlist/5653641561b4eba30a7e4929.m3u8) | <img height="20" src="https://i.imgur.com/84lWqRi.png"/> | TVN3.cl |
| 21 | Chilevisión Noticias | [>](https://redirector.rudo.video/hls-video/10b92cafdf3646cbc1e727f3dc76863621a327fd/chvn/chvn.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Qh6d0A9.png"/> | CHVNoticias.cl |
