<h1>Dominican Republic</h1>


| #   | Channel         | Link  | Logo | EPG id |
|:---:|:---------------:|:-----:|:----:|:------:|
| 4   | Canal RTVD 4       | [>](https://protvradiostream.com:1936/canal4rd-1/ngrp:canal4rd-1_all/playlist.m3u8) | <img height="20" src="https://static.wikia.nocookie.net/logopedia/images/4/4e/CERTV_4_2015.png"/> | Canal4RD.do |
