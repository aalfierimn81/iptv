<h1>Turkey</h1>

<h2>DVB-T</h2>

https://en.wikipedia.org/wiki/Television_in_Turkey


| #   | Channel          | Link  | Logo | EPG id |
|:---:|:----------------:|:-----:|:----:|:------:|
| 1   | TRT 1            | [>](https://tv-trt1.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/j786OLG.png"/> | TRT1.tr |
| 2   | TRT 2 Ⓖ         | [>](https://tv-trt2.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/lNWrOE2.png"/> | TRT2.tr |
| 3   | TRT Haber        | [>](https://tv-trthaber.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/OVfo8Ab.png"/> | TRTHaber.tr |
| 4   | TRT Spor Ⓖ      | [>](https://tv-trtspor1.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/N2wGZyf.png"/> | TRTSpor.tr |
| 5   | TRT Spor 2 Ⓖ    | [>](https://tv-trtspor2.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/ysKteM8.png"/> |
| 6   | TRT Çocuk        | [>](https://tv-trtcocuk.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/QLFmD6d.png"/> | TRTCocuk.tr |
| 7   | TRT Müzik        | [>](https://tv-trtmuzik.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/fIVFCEd.png"/> |
| 8   | TRT Belgesel     | [>](https://tv-trtbelgesel.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/MGO87pe.png"/> | TRTBelgesel.tr |
| 9   | TRT Avaz         | [>](https://tv-trtavaz.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/VhTwXu5.png"/> | TRTAvaz.tr |
| 10  | TRT Kurdî        | [>](https://tv-trtkurdi.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/6BpymfB.png"/> | TRTKurdi.tr |
| 11  | TRT Arabi        | [>](https://tv-trtarabi.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/yyhWOZs.png"/> | TRTArabi.tr |
| 12  | TRT World        | [>](https://tv-trtworld.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/JEA2xpv.png"/> | TRTWorld.tr |
| 13  | TRT Türk         | [>](https://tv-trtturk.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/OSTOQNw.png"/> | TRTTurk.tr |
| 14  | TRT EBA Ilkokul  | [>](https://tv-e-okul00.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/wDvZfk8.png"/> |
| 15  | TRT EBA Ortaokul | [>](https://tv-e-okul01.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/yfPTvRx.png"/> |
| 16  | TRT EBA Lise     | [>](https://tv-e-okul02.medya.trt.com.tr/master.m3u8) | <img height="20" src="https://i.imgur.com/IebUZx1.png"/> |

<h2>Other</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | TMB TV | [x](https://www.tvkaista.net/stream-forwarder/get.php?x=TMBTV) | <img height="20" src="https://upload.wikimedia.org/wikipedia/az/c/c2/TMB_TV_loqosu.png"/> | TMB.tr |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
