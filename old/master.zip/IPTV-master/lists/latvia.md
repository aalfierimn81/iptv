<h1>Latvia</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | LTV1 | [>](https://ltvlive2167.cloudycdn.services/ltvlive/_definst_/ltvlive_ltv06_ltv1_g_x44_43186_default_1326_hls.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/4/4a/LTV1_%282022%29.svg/768px-LTV1_%282022%29.svg.png"/> | LTV1.lv |
| 2   | LTV7 | [>](https://ltvlive2167.cloudycdn.services/ltvlive/_definst_/ltvlive_ltv07_ltv7_g_eb0_43187_default_1327_hls.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/f/f2/LTV7_Logo_2021.svg/768px-LTV7_Logo_2021.svg.png"/> | LTV7.lv |
| 4   | TV4 Ⓨ | [>](https://www.youtube.com/@helpsportacentrs/live) | <img height="20" src="https://i.imgur.com/91A5ZoP.png"/> | TV4Latvija.lv |
| 10  | TV24 | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/lv/3/36/Tv24_logo.png"/> | TV24.lv |
| 11  | ReTV | [>](https://retv2132.cloudycdn.services/slive/_definst_/retv_retv_channel_5k7_42787_default_891_hls.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/lv/thumb/d/db/ReTV_Logo_2022.svg/320px-ReTV_Logo_2022.svg.png"/> | ReTV.lv |
| 99  | Visiem LTV | [>](https://ltvlive2167.cloudycdn.services/ltvlive/_definst_/ltvlive_ltv09_visiem_ymc_43189_default_1329_hls.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wk73EzK.png"/> | VisiemLTV.lv |

<h3>Local channels</h3>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | TV Jūrmala     | [>](https://air.star.lv/TV_Jurmala_multistream/index.m3u8) | <img height="20" src="https://i.imgur.com/tQHkHD0.png"/> | TVJurmala.lv |
| 2   | Vidusdaugavas Televīzija | [>](https://straume.vdtv.lv/vdtv2/index.m3u8) | <img height="20" src="https://i.imgur.com/L5U3PQR.png"/> | VidusdaugavasTelevizija.lv |
