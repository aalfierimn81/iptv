<h1>Costa Rica</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1 |  Canal 1 |[>](https://video20.klm99.com:3993/live/canal1crlive.m3u8) | <img height="20" src="https://cloudfront-us-east-1.images.arcpublishing.com/gruponacion/2XI5OC6MQZFXXBDGMRRDOZSL2Q.jpg"/> | Canal1.cr |
| 2 |  Canal 2 CDR |[>](https://d3bgcstab9qhdz.cloudfront.net/hls/canal2.m3u8) | <img height="20" src="https://i0.wp.com/directostv.teleame.com/wp-content/uploads/2016/06/Canal-2-Costa-Rica-en-vivo-Online.png"/> | Canal2.cr |
| 4 |  Canal 4 |[>](https://d3bgcstab9qhdz.cloudfront.net/hls/canal2.m3u8) | <img height="20" src="https://i0.wp.com/directostv.teleame.com/wp-content/uploads/2016/06/Canal-4-Costa-Rica-en-vivo-Online.png"/> | Canal4.cr |
| 6 |  Canal 6 |[>](https://d3bgcstab9qhdz.cloudfront.net/hls/canal2.m3u8) | <img height="20" src="https://i0.wp.com/directostv.teleame.com/wp-content/uploads/2016/06/Canal-6-Costa-Rica-en-vivo-Online.png"/> | Canal6.cr |
| 8 |  Canal 8 |[>](http://mdstrm.com/live-stream-playlist/5a7b1e63a8da282c34d65445.m3u8) | <img height="20" src="https://platform-static.cdn.mdstrm.com/player/logo/5efe501c21d05a0722152f6d.png"/> | Canal8.cr |
| 11 |  Canal 11 |[>](https://d3bgcstab9qhdz.cloudfront.net/hls/canal2.m3u8) | <img height="20" src="https://i0.wp.com/directostv.teleame.com/wp-content/uploads/2016/06/Canal-11-Costa-Rica-en-vivo-Online.png"/> | Canal11.cr |
| 88 |  88 Stereo |[>](http://k3.usastreams.com/CableLatino/88stereo/playlist.m3u8) | <img height="20" src="http://www.88stereo.com/wp-content/uploads/2017/05/88Stereo-logoweb.png"/> | 88stereo.cr |
