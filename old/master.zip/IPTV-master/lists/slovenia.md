<h1>Slovenia</h1>

<h2>DVB-T</h2>

https://en.wikipedia.org/wiki/Television_in_Slovenia

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | TV SLO 1 | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=TVSLO1) | <img height="20" src="https://i.imgur.com/YIZOtcm.png"/> | TVSlovenija1.si |
| 2   | TV SLO 2 | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=TVSLO2) | <img height="20" src="https://i.imgur.com/mQe9U2h.png"/> | TVSlovenija2.si |
| 3   | TV SLO 3 | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=TVSLO3) | <img height="20" src="https://i.imgur.com/WGUyj7r.png"/> | TVSlovenija3.si |
| 4   | TV Koper/Capodistria | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=TVKC) | <img height="20" src="https://i.imgur.com/NQvOJNh.png"/> | TVKoperCapodistria.si |
| 5   | TV Maribor | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=TVMaribor) | <img height="20" src="https://i.imgur.com/tWf3dgf.png"/> | TVMaribor.si |
| 6   | MMC TV | [>](https://www.tvkaista.net/stream-forwarder/get.php?x=MMCTV) | <img height="20" src="https://i.imgur.com/yzETQJ4.png"/> | MMC.si |

<h2>DVB-S</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Nova 24 TV Ⓨ | [>](https://www.youtube.com/@Nova24TVSlovenija/live) | <img height="20" src="https://i.imgur.com/M2207Vh.png"/> | Nova24TV.si |

<h2>Web</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Folx Slovenija | [>](https://cdne.folxplay.tv/folx-trz/streams/ch-5/master.m3u8) | <img height="20" src="https://i.imgur.com/RK1IASU.png"/> | FolxSlovenija.si |
