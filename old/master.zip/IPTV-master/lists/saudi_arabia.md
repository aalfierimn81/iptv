<h1>Saudi Arabia</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Al Saudiya | [>](https://shls-masr2-ak.akamaized.net/out/v1/5ae66b453b62403199811ab78da9982a/index.m3u8) | <img height="20" src="https://i.imgur.com/GRQTndk.png"/> | AlSaudiya.sa |
| 2   | SBC Saudi Arabia | [>](https://sbc-prod-dub-ak.akamaized.net/out/v1/2eb1ad0f29984a339bc0fce4ce94dcbb/index.m3u8) | <img height="20" src="https://i.imgur.com/9JSQglj.png"/> | SBC.sa |
| 3   | Thikrayat | [>](https://edge.taghtia.com/sa/3.m3u8) | <img height="20" src="https://i.imgur.com/AKa1X9d.png"/> | ThikrayatTV.sa |
| 4   | Al Ekhbariya | [>](https://al-ekhbaria-prod-dub.shahid.net/out/v1/d443f3203b444032896e3233cb6eaa84/index.m3u8) | <img height="20" src="https://i.imgur.com/WcRlHQm.png"/> | AlEkhbariya.sa |
| 5   | Al Saudiya Alaan | [>](https://edge.taghtia.com/sa/17.m3u8) | <img height="20" src="https://i.imgur.com/sEOjApe.png"/> | AlSaudiyaAlaan.sa |
| 6   | KSA Sports 1 | [>](https://edge.taghtia.com/sa/9.m3u8) | <img height="20" src="https://i.imgur.com/ONKNOAp.png"/> | KSASports1.sa |
| 7   | KSA Sports 2 | [>](https://edge.taghtia.com/sa/10.m3u8) | <img height="20" src="https://i.imgur.com/v8ULLqg.png"/> | KSASports2.sa |
| 8   | KSA Sports 3 | [>](https://edge.taghtia.com/sa/16.m3u8) | <img height="20" src="https://i.imgur.com/BXfCvez.png"/> | KSASports3.sa |
| 9   | Al Quran Al Kareem TV | [>](https://edge.taghtia.com/sa/7.m3u8) | <img height="20" src="https://i.imgur.com/A2fJysM.png"/> | AlQuranAlKareemTV.sa |
| 10  | Al Sunnah Al Nabawiyah TV | [>](https://edge.taghtia.com/sa/6.m3u8) | <img height="20" src="https://i.imgur.com/S6LcTJv.png"/> | AlSunnahAlNabawiyahTV.sa |
