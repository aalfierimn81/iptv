<h1>Documentaries (AR)</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Al Jazeera Documentary Ⓖ | [>](https://live-hls-web-ajd.getaj.net/AJD/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/e/e6/Al_Jazeera_Doc.png"/> | AlJazeeraDocumentary.qa |
