<h1>Slovakia</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Jednotka    | [>](https://sktv-forwarders.7m.pl/get.php?x=STV1) | <img height="20" src="https://i.imgur.com/T7EWAe7.png"/> | Jednotka.sk |
| 2   | Dvojka    | [>](https://sktv-forwarders.7m.pl/get.php?x=STV2) | <img height="20" src="https://i.imgur.com/Ksi25UD.png"/> | Dvojka.sk |
| 3   | 24    | [>](https://sktv-forwarders.7m.pl/get.php?x=STV24) | <img height="20" src="https://i.imgur.com/sdSsFU0.png"/> | 24.sk |
| 4   | RTVS Šport    | [>](https://sktv-forwarders.7m.pl/get.php?x=SPORT) | <img height="20" src="https://i.imgur.com/YzHipRF.png"/> | Sport.sk |
| 5   | :O    | [>](https://sktv-forwarders.7m.pl/get.php?x=STV-O) | <img height="20" src="https://i.imgur.com/Nf5gEDc.png"/> |
| 6   | RTVS    | [>](https://sktv-forwarders.7m.pl/get.php?x=RTVS) | <img height="20" src="https://i.imgur.com/Nf5gEDc.png"/> |
| 7   | NR SR    | [>](https://sktv-forwarders.7m.pl/get.php?x=NR_SR) | <img height="20" src="https://i.imgur.com/sPDiS5q.png"/> | TVNRSR.sk |
| 8   | JOJ    | [>](https://live.cdn.joj.sk/live/andromeda/joj-1080.m3u8) | <img height="20" src="https://i.imgur.com/5BAWD0z.png"/> | TVJOJ.sk |
| 9   | JOJ Plus    | [>](https://live.cdn.joj.sk/live/andromeda/plus-1080.m3u8) | <img height="20" src="https://i.imgur.com/fKPliTj.png"/> | JOJPlus.sk |
| 10  | WAU    | [>](https://live.cdn.joj.sk/live/andromeda/wau-1080.m3u8) | <img height="20" src="https://i.imgur.com/wO5ifff.png"/> | JOJWAU.sk |
| 11  | JOJ 24    | [>](https://live.cdn.joj.sk/live/andromeda/joj_news-1080.m3u8) | <img height="20" src="https://i.imgur.com/owEVXRE.png"/> | JOJ24.sk |
| 12  | JOJ Šport    | [>](https://live.cdn.joj.sk/live/andromeda/joj_sport-1080.m3u8) | <img height="20" src="https://i.imgur.com/QWEY2a5.png"/> | JOJSport.sk |
| 13  | Senzi    | [>](http://lb.streaming.sk/senzi/stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/W82dwzf.png"/> | Senzi.sk |
| 14  | TA3 Ⓢ    | [>](https://sktv-forwarders.7m.pl/get.php?x=TA3) | <img height="20" src="https://i.imgur.com/kPFBxc9.png"/> | TA3.sk |
