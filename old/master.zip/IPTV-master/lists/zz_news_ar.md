<h1>News (AR)</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Al Jazeera العربية | [>](https://live-hls-web-aja.getaj.net/AJA/index.m3u8) | <img height="20" src="https://i.imgur.com/BB93NQP.png"/> | AlJazeeraChannel.qa |
| 2   | Al Arabiya العربية | [>](https://live.alarabiya.net/alarabiapublish/alarabiya.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/e/e0/Al-Arabiya_new_logo.svg/640px-Al-Arabiya_new_logo.svg.png"/> | AlArabiya.ae |
| 3   | France 24 العربية Ⓨ | [>](https://www.youtube.com/c/FRANCE24Arabic/live) | <img height="20" src="https://i.imgur.com/61MSiq9.png"/> | France24Arabic.fr |
| 4   | DW العربية | [>](https://dwamdstream103.akamaized.net/hls/live/2015526/dwstream103/index.m3u8) | <img height="20" src="https://i.imgur.com/A1xzjOI.png"/> | DWArabic.de |
| 5   | CGTN العربية | [>](https://news.cgtn.com/resource/live/arabic/cgtn-a.m3u8) | <img height="20" src="https://i.imgur.com/fMsJYzl.png"/> | CGTNArabic.cn |
| 6   | Sky News العربية | [>](https://stream.skynewsarabia.com/hls/sna.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/en/thumb/5/57/Sky_News_logo.svg/512px-Sky_News_logo.svg.png"/> | SkyNewsArabia.ae |
| 7   | RT العربية | [>](https://rt-arb.rttv.com/dvr/rtarab/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/a0/Russia-today-logo.svg/512px-Russia-today-logo.svg.png"/> | RTArabic.ru |
