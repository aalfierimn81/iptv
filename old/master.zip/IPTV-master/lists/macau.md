<h1>Macau</h1>

* https://en.wikipedia.org/wiki/TDM_(Macau)#Channels

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 91  | TDM Ou Mun | [>](https://live4.tdm.com.mo/ch1/ch1.live/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/zh/9/9b/TDM_Ou_Mun.png"/> | TDMOuMun.mo |
| 92  | Canal Macau | [>](https://live4.tdm.com.mo/ch2/ch2.live/playlist.m3u8) | <img height="20" src="https://i.imgur.com/oFPUZ97.png"/> | CanalMacau.mo |
| 93  | TDM Sport | [>](https://live4.tdm.com.mo/ch4/sport_ch4.live/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/zh/9/9b/TDM_Ou_Mun.png"/> | TDMSports.mo |
| 94  | TDM Information | [>](https://live4.tdm.com.mo/ch5/info_ch5.live/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/zh/9/9b/TDM_Ou_Mun.png"/> | TDMInformation.mo |
| 95  | TDM Entertainment | [>](https://live4.tdm.com.mo/ch6/hd_ch6.live/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/6/6c/TDM_Entertainment.png"/> | TDMEntertainment.mo |
| 96  | TDM Ou Mun-Macau | [>](https://live4.tdm.com.mo/ch3/ch3.live/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/zh/8/87/TDM_Ou_Mun_Macau_logo.png"/> | TDMMacauSatellite.mo |
