<h1>Faroe Islands</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | KVF Sjónvarp   | [>](https://w1.kringvarp.fo/uttanlands/smil:uttanlands.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/a/ab/KVF_logo_2019.svg/640px-KVF_logo_2019.svg.png"/> | KVFSjonvarp.fo |
| 2   | Tingvarp | [>](https://play.kringvarp.fo/redirect/tingvarp/_definst_/smil:tingvarp.smil?type=m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/9/90/Logo_-_L%C3%B8gting.png"/> | Tingvarp.fo |
