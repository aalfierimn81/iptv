<h1>United Arab Emirates</h1>

* https://www.lyngsat.com/freetv/United-Arab-Emirates.html
* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=50&num_genre=&num_crypt=1&num_standard=&ordre=freq (other than Abu Dhabi, Dubai or Sharjah)

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Cartoon Network Arabic | [>](https://shls-cartoon-net-prod-dub.shahid.net/out/v1/dc4aa87372374325a66be458f29eab0f/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/b/bb/Cartoon_Network_Arabic_logo.png"/> | CartoonNetworkArabic.ae |
| 2   | Al Arabiya Business | [>](https://live.alarabiya.net/alarabiapublish/aswaaq.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/eEV4r6J.jpg"/> | AlArabiyaBusiness.ae |

<h2>Abu Dhabi</h2>

* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=52&num_genre=&num_crypt=1&num_standard=&ordre=freq

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Abu Dhabi TV | [>](http://admdn2.cdn.mangomolo.com/adtv/smil:adtv.stream.smil/chunklist.m3u8) | <img height="20" src="https://i.imgur.com/7cNke07.png"/> | AbuDhabiTV.ae |
| 2   | Abu Dhabi Sports TV 1 | [>](https://admdn1.cdn.mangomolo.com/adsports1/smil:adsports1.stream.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Abu_Dhabi_Sports_logo_2023.svg/2560px-Abu_Dhabi_Sports_logo_2023.svg.png"/> | AbuDhabiSports2.ae |
| 3   | Abu Dhabi Sports TV 2 | [>](https://admdn5.cdn.mangomolo.com/adsports2/smil:adsports2.stream.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/7/7a/Abu_Dhabi_Sports_logo_2023.svg/2560px-Abu_Dhabi_Sports_logo_2023.svg.png"/> | AbuDhabiSports2.ae |
| 4   | National Geographic Abu Dhabi | [>](https://admdn2.cdn.mangomolo.com/nagtv/smil:nagtv.stream.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/fNA00VF.png"/> | NationalGeographicAbuDhabi.ae |

<h2>Ajman</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Ajman TV | [>](https://dacastmmd.mmdlive.lldns.net/dacastmmd/8eb0e912b49142d7a01d779c9374aba9/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/aa/ajman-tv-ae.png"/> | AjmanTV.ae |

<h2>Dubai</h2>

* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=49&num_genre=&num_crypt=1&num_standard=&ordre=freq

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Dubai TV | [>](https://dmisxthvll.cdn.mgmlcdn.com/dubaitvht/smil:dubaitv.stream.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/wZMkKF7.png"/> | DubaiTV.ae |
| 2   | Dubai One | [>](https://dminnvll.cdn.mangomolo.com/dubaione/smil:dubaione.stream.smil/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/7/7d/Dubaione-logo.png"/> | DubaiOne.ae |
| 3   | Dubai Sports 1 | [>](https://dmitnthfr.cdn.mgmlcdn.com/dubaisports/smil:dubaisports.stream.smil/chunklist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-sports-ae.png"/> | DubaiSports1.ae |
| 4   | Dubai Sports 2 | [>](https://dmitwlvvll.cdn.mangomolo.com/dubaisportshd/smil:dubaisportshd.smil/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-sports-ae.png"/> | DubaiSports2.ae |
| 5   | Dubai Sports 3 | [>](https://dmitwlvvll.cdn.mangomolo.com/dubaisportshd5/smil:dubaisportshd5.smil/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-sports-ae.png"/> | DubaiSports3.ae |
| 6   | Dubai Racing 1 | [>](https://dmisvthvll.cdn.mgmlcdn.com/events/smil:events.stream.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-racing-ae.png"/> | DubaiRacing1.ae |
| 7   | Dubai Racing 2 | [>](https://dmithrvll.cdn.mangomolo.com/dubairacing/smil:dubairacing.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-racing-ae.png"/> | DubaiRacing2.ae |
| 8   | Dubai Racing 3 | [>](https://dmithrvll.cdn.mangomolo.com/dubaimubasher/smil:dubaimubasher.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-racing-ae.png"/> | DubaiRacing3.ae |
| 9   | Dubai Zaman | [>](https://dmiffthvll.cdn.mangomolo.com/dubaizaman/smil:dubaizaman.stream.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/dd/dubai-zaman-ae.png"/> | DubaiZaman.ae |

<h2>Fujairah</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Fujairah TV | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/ff/fujairah-tv-ae.png"/> | FujairahTV.ae |

<h2>Ras Al Khaimah</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|

<h2>Sharjah</h2>

* https://en.kingofsat.tv/find2.php?pos=&cl=&num_pays=53&num_genre=&num_crypt=1&num_standard=&ordre=freq

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | Sharjah TV | [>](https://svs.itworkscdn.net/smc1live/smc1.smil/playlist.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/ss/sharjah-tv-ae.png"/> | SharjahTV.ae |
| 2   | Sharjah Sports | [>](https://svs.itworkscdn.net/smc4sportslive/smc4.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/IaRaabJ.jpg"/> | SharjahSports.ae |

<h2>Umm Al Quwain</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
