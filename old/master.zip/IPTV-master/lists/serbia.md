<h1>Serbia</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTS 1 | [>](https://webtvstream.bhtelecom.ba/rts1.m3u8) | <img height="20" src="https://i.imgur.com/S1pKHSR.png"/> | RTS1.rs |
| 2   | RTS 2 | [>](https://webtvstream.bhtelecom.ba/rts2.m3u8) | <img height="20" src="https://i.imgur.com/jltAf5h.png"/> | RTS2.rs |
| 3   | RTS 3 | [x]() | <img height="20" src="https://i.imgur.com/gxuGB4J.png"/> | RTS3.rs |
| 0   | RTS Svet | [x]() | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/8/8a/Rts-svet.png"/> | RTSSvet.rs |
| 0 | Euronews Serbia | [>](https://d1ei8ofhgfmkac.cloudfront.net/app-19518-1306/ngrp:QoZfNjsg_all/playlist.m3u8) | <img height="20" src="https://i.imgur.com/b24QKcq.png"/> | EuroNewsSerbia.rs |

<h3>Vojvodina</h3>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RTV 1 | [>](rtsp://212.200.255.151/rtv1) | <img height="20" src="https://i.imgur.com/CG44YT3.png"/> | RTV1.rs |
| 2   | RTV 2 | [>](rtsp://212.200.255.151/rtv2) | <img height="20" src="https://i.imgur.com/skpr66t.png"/> | RTV2.rs |
