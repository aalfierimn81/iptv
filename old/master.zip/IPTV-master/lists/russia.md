<h1>Russia</h1>

<h2>DVB-T2</h2>

https://ru.wikipedia.org/wiki/Цифровое_телевидение_в_России#Мультиплексы (only in Russian language)

|  # |      Channel       | Link  | Logo | EPG id |
|:--:|:------------------:|:-----:|:----:|:------:|
|  1 |   Первый канал   | [>](https://edge1.1internet.tv/dash-live2/streams/1tv-dvr/1tvdash.mpd) | <img height="20" src="https://i.imgur.com/1IqCGe9.png"/> | ChannelOne.ru |
|  2 |     Россия 1     | [>](https://player.smotrim.ru/iframe/stream/live_id/2961) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/6/64/Russia-1.svg/1024px-Russia-1.svg.png"/> | Russia1.ru |
|  3 |     Матч ТВ Ⓢ      | [>](https://streaming.televizor-24-tochka.ru/live/6.m3u8) | <img height="20" src="https://i.imgur.com/kFdooR4.png"/> | Match.ru |
|  4 |       НТВ Ⓢ        | [>](http://ott-cdn.ucom.am/s17/index.m3u8) | <img height="20" src="https://i.imgur.com/DtQX5P2.png"/> | NTV.ru |
|  5 |   Пятый канал Ⓢ    | [>](https://streaming.televizor-24-tochka.ru/live/8.m3u8) | <img height="20" src="https://i.imgur.com/u8Q69D9.png"/> | 5Kanal.ru |
|  6 | Россия-Культура Ⓢ  | [>](https://player.smotrim.ru/iframe/stream/live_id/19201) | <img height="20" src="https://i.imgur.com/S12gaLc.png"/> | RussiaK.ru |
|  7 |    Россия-24 Ⓢ     | [>](https://player.smotrim.ru/iframe/stream/live_id/21) | <img height="20" src="https://i.imgur.com/tpqsFzm.png"/> | Russia24.ru |
|  8 |     Карусель Ⓢ     | [>](https://streaming102.interskytech.com/live/232.m3u8) | <img height="20" src="https://i.imgur.com/4fFMlVq.png"/> | Karusel.ru |
|  9 |       ОТР Ⓢ        | [>](https://streaming.televizor-24-tochka.ru/live/12.m3u8) | <img height="20" src="https://i.imgur.com/QyZvT3e.png"/> | OTR.ru |
| 10 |     ТВ Центр Ⓢ     | [>](http://ott-cdn.ucom.am/s54/index.m3u8) | <img height="20" src="https://i.imgur.com/ZP0D6Rd.png"/> | TVCentr.ru |
| 11 |      Рен ТВ Ⓢ      | [>](https://streaming.televizor-24-tochka.ru/live/14.m3u8) | <img height="20" src="https://i.imgur.com/18TAzYV.png"/> | RENTV.ru |
| 12 |       Спас Ⓢ       | [>](https://spas.mediacdn.ru/cdn/spas/playlist.m3u8) | <img height="20" src="https://i.imgur.com/A6Cqsom.jpeg"/> | TelekanalSpas.ru |
| 13 |       СТС Ⓢ        | [>](http://ott-cdn.ucom.am/s52/04.m3u8) | <img height="20" src="https://i.imgur.com/y9bpqUD.png"/> | STS.ru |
| 14 |     Домашний Ⓢ     | [>](http://ott-cdn.ucom.am/s88/index.m3u8) | <img height="20" src="https://i.imgur.com/e8wlMIt.png"/> | Domashniy.ru |
| 15 |       ТВ-3 Ⓢ       | [>](https://streaming.televizor-24-tochka.ru/live/18.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9e/%D0%A2V3_logo_2023.svg/556px-%D0%A2V3_logo_2023.svg.png"/> | TV3.ru |
| 16 |     Пятница! Ⓢ     | [>](https://streaming.televizor-24-tochka.ru/live/19.m3u8) | <img height="20" src="https://i.imgur.com/rS11zVB.png"/> | Pyatnitsa.ru |
| 17 |      Звезда      | [>](https://tvchannelstream1.tvzvezda.ru/cdn/tvzvezda/playlist.m3u8) | <img height="20" src="https://i.imgur.com/c0L0ncA.png"/> | TelekanalZvezda.ru |
| 18 |        Мир         | [>](http://hls.mirtv.cdnvideo.ru/mirtv-parampublish/mirtv_2500/playlist.m3u8) | <img height="20" src="https://i.imgur.com/L2slsbG.png"/> | Mir.ru |
| 19 |       ТНТ Ⓢ        | [>](http://ott-cdn.ucom.am/s19/index.m3u8) | <img height="20" src="https://i.imgur.com/1WqIPOB.png"/> | TNT.ru |
| 20 |      Муз-ТВ Ⓢ      | [>](https://streaming102.interskytech.com/live/618.m3u8) | <img height="20" src="https://i.imgur.com/Ml3qqOF.png"/> | MuzTV.ru |
| 21 |        РБК         | [>](http://92.50.128.180/utv/1358/index.m3u8) | <img height="20" src="https://i.imgur.com/P2Qii5B.png"/> | RBKTV.ru |
| 22 |     RT Д Русский Ⓖ   | [>](https://hls.rt.com/hls/rtdru.m3u8) | <img height="20" src="https://i.imgur.com/v5fpEBo.png"/> | RTD.ru |
| 23 |    CGTN Pусский    | [>](https://news.cgtn.com/resource/live/russian/cgtn-r.m3u8) | <img height="20" src="https://i.imgur.com/fMsJYzl.png"/> | CGTNRussian.cn |
| 24 | Euronews по-русски | [>](https://euronews.alteox.app/hls/ru_stream.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/thumb/9/9c/Euronews_2022.svg/640px-Euronews_2022.svg.png"/> | EuronewsRussian.fr |
| 25 | РТР-Планета Ⓢ | [>](https://player.smotrim.ru/iframe/stream/live_id/63251) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/8/85/RTR_Planeta_Europe.png"/> | RTRPlaneta.ru |

<h2>Regional</h2>

* Livestreams from YouTube-like services:
    * https://www.pomorie.ru/arctica24/ (VK Video)
    * https://katun24.ru/k24, https://kuban24.tv/tv (OK.ru)

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Арктика 24 Ⓥ | [>](https://vk.com/video-213370539_456239018) | <img height="20" src="https://i.imgur.com/CL0G88u.png"/> | Arktika24.ru |
| 0   | Архыз 24 | [>](https://live.mediacdn.ru/sr1/arhis24/playlist_hdhigh.m3u8) | <img height="20" src="https://i.imgur.com/mve0sSS.png"/> | Arkhyz24.ru |
| 0   | Астрахан 24 | [>](https://streaming.astrakhan.ru/astrakhan24/playlist.m3u8) | <img height="20" src="https://i.imgur.com/9WcnjQN.png"/> | Astrakhan24.ru |
| 0   | Башкортостан 24 | [>](https://vgtrkregion-reg.cdnvideo.ru/vgtrk/ufa/russia1-hd/index.m3u8) | <img height="20" src="https://i.imgur.com/FQhWs1M.png"/> | Bashkortostan24.ru |
| 0   | Белгород 24 | [>](http://belnovosti.cdn.easyhoster.ru:8080/stream.m3u8) | <img height="20" src="https://i.imgur.com/EEirvyx.png"/> | Belgorod24.ru |
| 0   | Ветта 24 | [>](http://serv24.vintera.tv:8081/vetta/vetta_office/playlist.m3u8) | <img height="20" src="https://i.imgur.com/zKH1b5k.png"/> | Vetta24.ru |
| 0   | Волгоград 24 Ⓢ | [>](https://vgtrkregion-reg.cdnvideo.ru/vgtrk/volgograd/russia1-hd/index.m3u8) | <img height="20" src="https://i.imgur.com/gFMnaU5.png"/> | Volgograd24.ru |
| 0   | Запад 24 | [>](https://vgtrkregion-reg.cdnvideo.ru/vgtrk/kaliningrad/russia1-hd/index.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/f/f8/Zapad_24.jpg"/> | Zapad24.ru |
| 0   | Кавказ 24 | [x]() | <img height="20" src="https://i.imgur.com/DyJw1Pi.png"/> | Kavkaz24.ru |
| 0   | Катунь 24 Ⓞ | [>](https://ok.ru/video/1166706155179) | <img height="20" src="https://i.imgur.com/mr2Peqj.png"/> | Katun24.ru |
| 0   | Крым 24 | [>](https://cdn.1tvcrimea.ru/24tvcrimea.m3u8) | <img height="20" src="https://i.imgur.com/k4C0uvp.png"/> | Crimea24.ru |
| 0   | Кубань 24 Ⓞ | [>](https://ok.ru/video/4157442498242) | <img height="20" src="https://i.imgur.com/atzrXcz.png"/> | Kuban24.ru |
| 0   | Луганск 24 | [>](https://tv.gtrklnr.ru/hls/Lugansk24.m3u8) | <img height="20" src="https://i.imgur.com/YnLFQnt.png"/> | Lugansk24.ua |
| 0   | Мир Белогорья | [>](http://mirbelogorya.ru:8080/mirbelogorya/index.m3u8) | <img height="20" src="https://i.imgur.com/CCNAg7R.png"/> | MirBelogorya.ru |
| 0   | Москва 24 | [>](https://player.smotrim.ru/iframe/stream/live_id/1661) | <img height="20" src="https://i.imgur.com/gXbUMVy.png"/> | Moskva24.ru |
| 0   | Нижний Новгород 24 | [>](https://live-vestinn.cdnvideo.ru/vestinn/nn24-khl/playlist.m3u8) | <img height="20" src="https://i.imgur.com/ZWgPVIC.png"/> | NizhniyNovgorod24.ru |
| 0   | Самара 24 | [>](https://vgtrkregion.cdnvideo.ru/vgtrk/samara/regionHD/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Xg7Xzna.png"/> | Samara24.ru |
| 0   | Саратов 24 | [>](https://saratov24.tv/online/playlist.php) | <img height="20" src="https://i.imgur.com/Y5G3ET6.png"/> | Saratov24.ru |
| 0   | Сибирь 24 | [>](https://vgtrkregion-reg.cdnvideo.ru/vgtrk/novosibirsk/russia1-hd/index.m3u8) | <img height="20" src="https://i.imgur.com/WxU6QUB.png"/> | Sibir24.ru |
| 0   | Тольятти 24 | [>](https://tvtogliatti24.ru/hls/live1080/index.m3u8) | <img height="20" src="https://i.imgur.com/5jVKopE.png"/> | Tolyatti24.ru |
| 0   | Урал 24 | [>](https://vgtrkregion-reg.cdnvideo.ru/vgtrk/chelyabinsk/russia1-hd/index.m3u8) | <img height="20" src="https://i.imgur.com/EaxyGh0.png"/> | Ural24.ru |
| 0   | Якутия 24 | [>](https://live-saha.cdnvideo.ru/saha2/yak24rtmp_live.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/2BAQklm.png"/> | Yakutiya24.ru |

<h2>Web</h2>

* https://smotrim.ru/live/

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | 360 Новости | [>](https://live-vgtrksmotrim.cdnvideo.ru/vgtrksmotrim/smotrim-live-03-srt.smil/playlist.m3u8) | <img height="20" src="https://i.imgur.com/YXDeX8q.png"/> | 360News.ru |
| 0   | Вести ФМ | [>](https://player.smotrim.ru/iframe/stream/live_id/52035) | <img height="20" src="https://cdn-st3.smotrim.ru/vh/pictures/r/371/033/8.png"/> |
| 0   | Небеса ТВ7 Ⓢ | [>](https://vod.tv7.fi/tv7-ru/tv7-ru.smil/playlist.m3u8) | <img height="20" src="https://www.nebesatv7.com/wp-content/themes/tv7-theme/assets/img/logo_nebesa_short.png"/> | NebesaTV7.ru |
| 0   | Север | [>](https://live.mediacdn.ru/sr1/sever/playlist.m3u8) | <img height="20" src="https://i.imgur.com/sTOQLYl.png"/> | Sever.ru |
| 0   | Смотрим - Детям | [x]() | <img height="20" src="https://cdn-st1.smotrim.ru/vh/pictures/r/424/215/2.png"/> |
| 0   | Смотрим - Мелодрамы | [>](https://live-vgtrksmotrim.cdnvideo.ru/vgtrksmotrim/smotrim-live-02.smil/playlist.m3u8) | <img height="20" src="https://cdn-st1.smotrim.ru/vh/pictures/r/456/967/6.png"/> |
| 0   | Смотрим - Тайны | [>](https://live-vgtrksmotrim.cdnvideo.ru/vgtrksmotrim/smotrim-live-07.smil/playlist.m3u8) | <img height="20" src="https://cdn-st3.smotrim.ru/vh/pictures/r/456/396/2.png"/> |
| 0   | Смотрим - Честный Детектив | [>](https://live-vgtrksmotrim.cdnvideo.ru/vgtrksmotrim/smotrim-live-01.smil/playlist.m3u8) | <img height="20" src="https://cdn-st3.smotrim.ru/vh/pictures/r/444/241/8.png"/> |
| 0   | Соловьёв Live | [>](https://player.smotrim.ru/iframe/stream/live_id/63338) | <img height="20" src="https://i.imgur.com/v0OYe1d.png"/> | SolovyovLive.ru |
| 0   | Ю Ⓢ | [>](https://strm.yandex.ru/kal/utv/utv0.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/ru/a/ac/%D0%9B%D0%BE%D0%B3%D0%BE%D1%82%D0%B8%D0%BF_%D1%82%D0%B5%D0%BB%D0%B5%D0%BA%D0%B0%D0%BD%D0%B0%D0%BB%D0%B0_%C2%AB%D0%AE%C2%BB_%28%D1%81_3_%D1%81%D0%B5%D0%BD%D1%82%D1%8F%D0%B1%D1%80%D1%8F_2018_%D0%B3%D0%BE%D0%B4%D0%B0%29.png"/> | U.ru |

<h2>DVB-S</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Матч! Планета Ⓢ | [>](http://212.0.211.102:9999/play/a00b/index.m3u8) | <img height="20" src="https://i.imgur.com/vhyMb9D.png"/> | MatchPlaneta.ru |

<h2>Invalid</h2>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
