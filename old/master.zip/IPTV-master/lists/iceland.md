<h1>Iceland</h1>

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 1   | RÚV     | [>](https://ruv-web-live.akamaized.net/streymi/ruverl/ruverl.m3u8) | <img height="20" src="https://i.imgur.com/vxaSn1K.png"/> | RUV.is |
| 2   | RÚV 2   | [>](https://ruvlive.akamaized.net/out/v1/2ff7673de40f419fa5164498fae89089/index.m3u8) | <img height="20" src="https://i.imgur.com/yDKRuXQ.png"/> | RUV2.is |
| 99  | Alþingi | [>](https://althingi-live.secure.footprint.net/althingi/live/index.m3u8) | <img height="20" src="https://i.imgur.com/n170HMm.png"/> | Althingi.is |
