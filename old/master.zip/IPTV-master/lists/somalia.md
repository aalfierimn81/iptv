<h1>Somalia</h1>

<h2>DVB-S</h2>

* https://www.lyngsat.com/freetv/Somalia.html

| #   | Channel        | Link  | Logo | EPG id |
|:---:|:--------------:|:-----:|:----:|:------:|
| 0   | Banaadir TV | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/bb/banaadir-tv-so.png"/> |
| 0   | Bulsho TV | [x]() | <img height="20" src="https://i.imgur.com/7qo4rb7.png"/> | BulshoTV.so |
| 0   | Codka Bariga Afrika | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/cc/codka-bariga-afrika-uk-so.png"/> | CodkaBarigaAfrika.so |
| 0   | Dacwa TV Ⓢ | [>](https://ap02.iqplay.tv:8082/iqb8002/d13w1/playlist.m3u8) | <img height="20" src="https://i.imgur.com/rMqrLzV.png"/> | DacwaTV.so |
| 0   | Galmudug TV | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/gg/galmudug-tv-so.png"/> |
| 0   | Hirshabelle TV | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/hh/hirshabelle-tvjpg-so.png"/> |
| 0   | Horn Cable TV | [x]() | <img height="20" src="https://i.imgur.com/qUqQCjP.png"/> | HornCableTV.so |
| 0   | Jubbaland TV | [x]() | <img height="20" src="https://i.imgur.com/SEgEYjV.png"/> | JubbalandTV.so |
| 0   | KGS TV | [x]() | <img height="20" src="https://i.imgur.com/MCDFlCk.png"/> | KGSTV.so |
| 0   | MM Somali TV Ⓢ | [>](https://cdn.mediavisionuk.com:9000/MMTV/index.m3u8) | <img height="20" src="https://www.lyngsat.com/logo/tv/mm/mm-somali-tv-so.png"/> | MMSomaliTV.uk |
| 0   | Puntland TV Ⓢ | [>](http://cdn.mediavisionuae.com:1935/live/putlandtv2.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/C8EvQUo.png"/> | PuntlandTV.so |
| 0   | Rejo TV | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/rr/rejo-tv-so.png"/> |
| 0   | Saab TV Ⓢ | [>](https://ap02.iqplay.tv:8082/iqb8002/s03btv/playlist.m3u8) | <img height="20" src="https://i.imgur.com/JEC1J89.png"/> | SaabTV.so |
| 0   | Sahan TV | [x]() | <img height="20" src="https://i.imgur.com/fOvHhX2.png"/> | SahanTV.so |
| 0   | SBC Somalia Ⓢ | [>](http://cdn.mediavisionuae.com:1935/live/sbctv.stream/playlist.m3u8) | <img height="20" src="https://i.imgur.com/VLhgTIA.png"/> | SBCTV.so |
| 0   | Shabelle TV | [x]() | <img height="20" src="https://www.lyngsat.com/logo/tv/ss/shabelle-tv-so.png"/> |
| 0   | SNTV Daljir Ⓢ | [>](https://ap02.iqplay.tv:8082/iqb8002/s2tve/playlist.m3u8) | <img height="20" src="https://i.imgur.com/Re3ur88.png"/> | SNTVDaljir.so |
| 0   | Somali Cable TV Ⓢ | [>](https://ap02.iqplay.tv:8082/iqb8002/somc131/playlist.m3u8) | <img height="20" src="https://i.imgur.com/iPkaCts.png"/> | SomaliCableTV.uk |
| 0   | Somali National TV Ⓢ | [>](https://ap02.iqplay.tv:8082/iqb8002/s4ne/playlist.m3u8) | <img height="20" src="https://upload.wikimedia.org/wikipedia/commons/d/d6/SNTV_REBRANDED_LOGO.png"/> | SomaliNationalTV.so |
| 0   | Somaliland National TV | [x]() | <img height="20" src="https://i.imgur.com/FIuQNWN.png"/> | SomalilandNationalTV.so |
